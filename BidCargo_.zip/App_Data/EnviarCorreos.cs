﻿using System;
using System.Globalization;
using System.Net.Mail;
using System.Data;
using System.Linq;

public class EnviarCorreos
{
    private static Random random = new Random();
    public void EnviarCorreo(string correoAlQueEnvio, string asuntoDelCorreo, string copiaCorreoEnvio, string textoDelCorreo, string correoDesdeElQueEnvio, string usuarioCorreEnvio, string contrasenaCorreoEnvio, string archivo)
    {
        /*-------------------------MENSAJE DE CORREO----------------------*/
        System.Net.Mail.MailMessage mmsg = new System.Net.Mail.MailMessage();
        //Direccion de correo electronico a la que queremos enviar el mensaje
        mmsg.To.Add(correoAlQueEnvio);
        //Asunto
        mmsg.Subject = asuntoDelCorreo;
        mmsg.SubjectEncoding = System.Text.Encoding.UTF32;
        //Direccion de correo electronico que queremos que reciba una copia del mensaje
        mmsg.Bcc.Add(copiaCorreoEnvio);
        //Cuerpo del Mensaje
        mmsg.Body = textoDelCorreo;

        //Cargar Imagen
        //string htmlBody = "";
        //htmlBody = htmlBody + "<img src=\"cid:closetEscritorio\">" + Environment.NewLine;
        //mmsg.IsBodyHtml = true;
        //mmsg.Body = htmlBody;
        //AlternateView htmlview = default(AlternateView);
        //htmlview = AlternateView.CreateAlternateViewFromString(htmlBody, null, "text/html");
        //MemoryStream logo = new MemoryStream();
        //LinkedResource imageResourceEs = new LinkedResource(HttpContext.Current.Server.MapPath("~//Images//" + "closetEscritorio.jpg"));
        //imageResourceEs.ContentId = "photo";
        //imageResourceEs.TransferEncoding = System.Net.Mime.TransferEncoding.Base64;
        //htmlview.LinkedResources.Add(imageResourceEs);
        //mmsg.AlternateViews.Add(htmlview);

        mmsg.BodyEncoding = System.Text.Encoding.UTF32;
        mmsg.IsBodyHtml = true;
        if (archivo.Length > 2) mmsg.Attachments.Add(new Attachment(archivo));
        //Correo electronico desde la que enviamos el mensaje
        mmsg.From = new System.Net.Mail.MailAddress(correoDesdeElQueEnvio);

        /*-------------------------CLIENTE DE CORREO----------------------*/
        System.Net.Mail.SmtpClient cliente = new System.Net.Mail.SmtpClient();
        //Hay que crear las credenciales del correo emisor
        cliente.Credentials = new System.Net.NetworkCredential(usuarioCorreEnvio, contrasenaCorreoEnvio);
        //Lo siguiente es obligatorio si enviamos el mensaje desde Gmail
        cliente.Port = 587;
        //cliente.EnableSsl = true;
        cliente.Host = "mail.bidcargo.com.co";
        mmsg.IsBodyHtml = true;
        try
        {
            cliente.Send(mmsg);
        }
        catch (System.Net.Mail.SmtpException ex)
        {
            string osa = ex.Message;
        }
    }
    public string ArmarCorreoPhone(string phone = "")
    {
        string strBody = "<HTML>";
        strBody += "<Body> ";
        strBody += "<label style='font-family: Arial, icomoon, sans-serif; font-size: 12px; color: #1F1F1F'>";
        strBody += "<br> Equipo de BidCargo <br>";
        strBody += "<br>La persona de este numero celular: "+phone+ ", esta esperando a que se pongan en contacto con el...";
        strBody += "<br> para conocer así sus necesidades";
        strBody += "<br><br><strong><span style=\"color:#000000\">Coordialmente</span></br></strong>";
        strBody += "<span style =\"color:#000000\">Servicio Al Cliente</span> </br></br>";
        strBody += "<br><br>";
        strBody += "<img src=\"http://www.bidcargo.com.co/Content/images/logoLetras.png\" width= \"428\" height=\"78\" alt=\"logo\">";
        strBody += "<br><br>";
        strBody += "<span style=\"color:#00ccff\">Antes de imprimir este correo electrónico, piense bien si es necesario hacerlo: El medio ambiente es cuestión de todos. Si decide imprimirlo, piense si es necesario hacerlo en color: el consumo de tinta o tóner será&nbsp;mucho mayor. Si decide imprimirlo en color, piense si necesita imprimir todo el documento o sólo una parte.</span > ";
        strBody += "</label>";
        strBody += "</Body>";
        strBody += "</HTML>";
        return strBody;
    }
    public string ArmarCorreoAprovedProfile(dynamic row = null, string urlpath = "", int prof= 0)
    {
        string strBody = "<HTML>";
        strBody += "<Body> ";
        strBody += "<label style='font-family: Arial, icomoon, sans-serif; font-size: 12px; color: #1F1F1F'>";
        strBody += "<br> Equipo de BidCargo <br>";
        strBody += "<br>Un placer saludarl@ "+row["usuarioFaceBook"]+", de parte del Equipo de BidCargo...";
        if(prof == 0)
        {
            strBody += "<br>Lamentamos informarle que su perfil en nuestra plataforma NO FUE APROBADO, y NO PUEDE INGRESAR a la misma.";
            strBody += "<br>Por favor, contacte con nuestros administradores, disculpe las molestias ocacionadas";
        }
        else
        {
            strBody += "<br>Nos complace informarle que su perfil en nuestra plataforma fue APROBADO, y ya PUEDE INGRESAR a la misma,";
            strBody += "<br>para disfrutar de nuestros servicios";
        }
        strBody += "<br><br><a href='" + urlpath + "'><button class=\"curpointer\" style=\"cursor:pointer;background:#42a098;border-radius:5px;padding:15px 23px;color:#ffffff;" +
            "           display:inline-block;font:normal bold 30px/1 \"Calibri\", sans-serif;text-align:center;text-shadow:1px 1px #000000;cursor:pointer;\"> BidCargo </button></a> ";
        strBody += "<br><br><strong><span style=\"color:#000000\">Coordialmente</span></br></strong>";
        strBody += "<span style =\"color:#000000\">Servicio Al Cliente</span> </br></br>";
        strBody += "<br><br>";
        strBody += "<img src=\"http://www.bidcargo.com.co/Content/images/logoLetras.png\" width= \"428\" height=\"78\" alt=\"logo\">";
        strBody += "<br><br>";
        strBody += "<span style=\"color:#00ccff\">Antes de imprimir este correo electrónico, piense bien si es necesario hacerlo: El medio ambiente es cuestión de todos. Si decide imprimirlo, piense si es necesario hacerlo en color: el consumo de tinta o tóner será&nbsp;mucho mayor. Si decide imprimirlo en color, piense si necesita imprimir todo el documento o sólo una parte.</span > ";
        strBody += "</label>";
        strBody += "</Body>";
        strBody += "</HTML>";
        return strBody;
    }
    public string sendMailAccepOffer(dynamic row = null,string urlpath = "")
    {
        string strBody = "<HTML>";
        strBody += "<Body> ";
        strBody += "<label style='font-family: Arial, icomoon, sans-serif; font-size: 12px; color: #1F1F1F'>";
        strBody += "<br> Equipo de BidCargo <br>";
        strBody += "<br>Un placer saludarl@ " + row["usuarioFaceBook"] + ", de parte del Equipo de BidCargo...";

        strBody += "<br>Nos complace informarle, que la oferta que realizo a la Cotizacion "+row["codeOffer"]+", ha sido acetada.";
        strBody += "<br>Le invitamos a ingresar a nuestra plataforma para conocer mas detalles";
        strBody += "<br><br><a href='" + urlpath + "'><button class=\"curpointer\" style=\"cursor:pointer;background:#42a098;border-radius:5px;padding:15px 23px;color:#ffffff;" +
            "           display:inline-block;font:normal bold 30px/1 \"Calibri\", sans-serif;text-align:center;text-shadow:1px 1px #000000;cursor:pointer;\"> BidCargo </button></a> ";
        strBody += "<br><br><strong><span style=\"color:#000000\">Coordialmente</span></br></strong>";
        strBody += "<span style =\"color:#000000\">Servicio Al Cliente</span> </br></br>";
        strBody += "<br><br>";
        strBody += "<img src=\"http://www.bidcargo.com.co/Content/images/logoLetras.png\" width= \"428\" height=\"78\" alt=\"logo\">";
        strBody += "<br><br>";
        strBody += "<span style=\"color:#00ccff\">Antes de imprimir este correo electrónico, piense bien si es necesario hacerlo: El medio ambiente es cuestión de todos. Si decide imprimirlo, piense si es necesario hacerlo en color: el consumo de tinta o tóner será&nbsp;mucho mayor. Si decide imprimirlo en color, piense si necesita imprimir todo el documento o sólo una parte.</span > ";
        strBody += "</label>";
        strBody += "</Body>";
        strBody += "</HTML>";
        return strBody;
    }
    public string sendMailContraOffer(string codeOffer = "" , string urlpath = "")
    {
        string strBody = "<HTML>";
        strBody += "<Body> ";
        strBody += "<label style='font-family: Arial, icomoon, sans-serif; font-size: 12px; color: #1F1F1F'>";
        strBody += "<br> Equipo de BidCargo <br>";
        strBody += "<br>Un placer saludarlo...";

        strBody += "<br>Nos complace informarle, que la a oferta, codigo, "+ codeOffer + " le han realizado una Oferta de Servicio.";
        strBody += "<br>Le invitamos a ingresar a nuestra plataforma para conocer mas detalles";
        strBody += "<br><br><a href='" + urlpath + "'><button class=\"curpointer\" style=\"cursor:pointer;background:#42a098;border-radius:5px;padding:15px 23px;color:#ffffff;" +
            "           display:inline-block;font:normal bold 30px/1 \"Calibri\", sans-serif;text-align:center;text-shadow:1px 1px #000000;cursor:pointer;\"> BidCargo </button></a> ";
        strBody += "<br><br><strong><span style=\"color:#000000\">Coordialmente</span></br></strong>";
        strBody += "<span style =\"color:#000000\">Servicio Al Cliente</span> </br></br>";
        strBody += "<br><br>";
        strBody += "<img src=\"http://www.bidcargo.com.co/Content/images/logoLetras.png\" width= \"428\" height=\"78\" alt=\"logo\">";
        strBody += "<br><br>";
        strBody += "<span style=\"color:#00ccff\">Antes de imprimir este correo electrónico, piense bien si es necesario hacerlo: El medio ambiente es cuestión de todos. Si decide imprimirlo, piense si es necesario hacerlo en color: el consumo de tinta o tóner será&nbsp;mucho mayor. Si decide imprimirlo en color, piense si necesita imprimir todo el documento o sólo una parte.</span > ";
        strBody += "</label>";
        strBody += "</Body>";
        strBody += "</HTML>";
        return strBody;
    }

    public string ArmarCorreoActiveProfile(dynamic row = null, string urlpath = "", int prof = 0)
    {
        string strBody = "<HTML>";
        strBody += "<Body> ";
        strBody += "<label style='font-family: Arial, icomoon, sans-serif; font-size: 12px; color: #1F1F1F'>";
        strBody += "<br> Equipo de BidCargo <br>";
        strBody += "<br>Un placer saludarl@ " + row["usuarioFaceBook"] + ", de parte del Equipo de BidCargo...";
        if (prof == 0)
        {
            strBody += "<br>Lamentamos informarle que su perfil en nuestra plataforma FUE DESACTIVADO.";
        }
        else
        {
            strBody += "<br>Nos complace informarle que su perfil en nuestra plataforma fue ACTIVADO, y se ENCUENTRA EN REVISION,";
        }
        strBody += "<br>Por favor, contacte con nuestros administradores, disculpe las molestias ocacionadas";
        strBody += "<br><br><a href='" + urlpath + "'><button class=\"curpointer\" style=\"cursor:pointer;background:#42a098;border-radius:5px;padding:15px 23px;color:#ffffff;" +
            "           display:inline-block;font:normal bold 30px/1 \"Calibri\", sans-serif;text-align:center;text-shadow:1px 1px #000000;cursor:pointer;\"> BidCargo </button></a> ";
        strBody += "<br><br><strong><span style=\"color:#000000\">Coordialmente</span></br></strong>";
        strBody += "<span style =\"color:#000000\">Servicio Al Cliente</span> </br></br>";
        strBody += "<br><br>";
        strBody += "<img src=\"http://www.bidcargo.com.co/Content/images/logoLetras.png\" width= \"428\" height=\"78\" alt=\"logo\">";
        strBody += "<br><br>";
        strBody += "<span style=\"color:#00ccff\">Antes de imprimir este correo electrónico, piense bien si es necesario hacerlo: El medio ambiente es cuestión de todos. Si decide imprimirlo, piense si es necesario hacerlo en color: el consumo de tinta o tóner será&nbsp;mucho mayor. Si decide imprimirlo en color, piense si necesita imprimir todo el documento o sólo una parte.</span > ";
        strBody += "</label>";
        strBody += "</Body>";
        strBody += "</HTML>";
        return strBody;
    }
    
    public string ArmarCorreoRecuperacionContrasena(string nombreUsuario, string contrasena, int genero, string celular, string urlpath)
    {
        string strBody = "<HTML>";
        strBody += "<head><style type=\"text/css\">.curpointer {cursor: pointer;}</style></head> ";
        strBody += "<Body> ";
        strBody += "<label style='font-family: Arial, icomoon, sans-serif; font-size: 12px; color: #1F1F1F'>";
        strBody += "<br> Estimad@ " + nombreUsuario + ", <br>";
        strBody += "<br> Si haz solicitado una actualización de contraseña, realiza clic en el siguiente botón.";
        strBody += "<br><br> Si no haz realizado la solicitud, ignora este email";
        strBody += "<br><br> Tu contraseña temporal es: " + contrasena + "<br><br>";
        strBody += "<a href='"+ urlpath+"/Home/actualizarContrasena?id={1}'><button class=\"curpointer\" style=\"background:#0219ba;border-radius:5px;padding:15px 23px;color:#ffffff;display:inline-block;font:normal bold 30px \"Calibri\", sans-serif;text-align:center;text-shadow:1px 1px #000000;cursor:pointer;\">Cambiar Contraseña</button></a> ";
        strBody += "<br><br>Gracias,";
        strBody += "<br><br>BidCargo equipo de soporte";
        strBody += "<br><br><img src=\"http://www.bidcargo.com.co/Content/images/logoLetras.png\" width= \"428\" height=\"78\" alt=\"logo\">";
        strBody += "<br><br>";
        strBody += "</label>";
        strBody += "</Body>";
        strBody += "</HTML>";
        strBody = strBody.Replace("{1}", celular);
        return strBody;
    }

    public string ArmarCorreoElectronico(string nombreUsuario, int genero, string celular, string tema)
    {
        string strBody = "<HTML>";
        strBody += "<Body> ";
        strBody += "<label style='font-family: Arial, icomoon, sans-serif; font-size: 12px; color: #1F1F1F'>";
        strBody += "<br> Estimado(a) " + nombreUsuario + " <br><br> Muchas grácias por comunicarse con nosotros";
        strBody += "<br><br> Por medio del presente, deseo confirmarle que una persona de nuestro equipo se comunicará con usted";
        strBody += "<br> para conocer así sus necesidades";
        strBody += "<br> El número al que lo llamaremos es: " + celular;
        strBody += "<br> El tema del que quieres saber es: " + tema;
        strBody += "<br><br><strong><span style=\"color:#000000\">Coordialmente</span></br></strong>";
        strBody += "<span style =\"color:#000000\">Servicio Al Cliente</span> </br></br>";
        strBody += "<br><br>";
        strBody += "<img src=\"http://www.bidcargo.com.co/Content/images/logoLetras.png\" width= \"428\" height=\"78\" alt=\"logo\">";
        strBody += "<br><br>";
        strBody += "<span style=\"color:#00ccff\">Antes de imprimir este correo electrónico, piense bien si es necesario hacerlo: El medio ambiente es cuestión de todos. Si decide imprimirlo, piense si es necesario hacerlo en color: el consumo de tinta o tóner será&nbsp;mucho mayor. Si decide imprimirlo en color, piense si necesita imprimir todo el documento o sólo una parte.</span > ";
        strBody += "</label>";
        strBody += "</Body>";
        strBody += "</HTML>";   
        return strBody;
    }

    public string ArmarCorreoElectronicoPrimerContacto(string name, string LastName, string contrasena, string usuario, string celular, string urlpath)
    {
        string strBody = "<HTML>";
        strBody += "<Body> ";
        strBody += "<label style='font-family: Arial, icomoon, sans-serif; font-size: 12px; color: #1F1F1F'>";
        strBody += "<br> Bienvenido " + name + " " + LastName + " A la plataforma de BidCargo, <br><br>plataforma comprometida con tu crecimiento empresarial.";
        strBody += "<br> Has iniciado el proceso de pre-registro en la plataforma colaborativa de BidCargo; para continuar con el proceso de inscripción definitivo ";
        strBody += "te estamos enviando el usuario y la contraseña temporal. Al ingresar nuevamente, la plataforma te solicitará que cambies tu Clave. Si tienes algún inconveniente, por favor contáctanos a través del correo contacto@bidcargo.com.co";
        strBody += "<br> USUARIO: " + usuario;
        strBody += "<br> CONTRASEÑA: " + contrasena + "<br><br>";
        strBody += "<a href='"+urlpath+"/Home/actualizarContrasena?id={1}'><button class=\"curpointer\" style=\"background:#0219ba;border-radius:5px;padding:15px 23px;color:#ffffff;display:inline-block;font:normal bold 30px \"Calibri\", sans-serif;text-align:center;text-shadow:1px 1px #000000;cursor:pointer;\">Activar Cuenta</button></a> ";
        strBody += "<br><br>Cordialmente Servicio al cliente BidCargo";
        strBody += "<br><br><img src=\"http://www.bidcargo.com.co/Content/images/logoLetras.png\" width= \"428\" height=\"78\" alt=\"logo\">";
        strBody += "</label>";
        strBody += "</Body>";
        strBody += "</HTML>";
        strBody = strBody.Replace("{1}", celular);
        return strBody;


    }
    public static string RandomString(int length)
    {
        const string chars = "ABCDEFGHIJLMNOPQRSTUVWXYZabcdefghijlmnopqrstuvwxyz0123456789";
        return new string(Enumerable.Repeat(chars, length)
          .Select(s => s[random.Next(s.Length)]).ToArray());
    }
    public string sendOfferMail( System.Data.DataRowCollection model, string apellidoPaterno, string urlpath)
    {
        string strBody = "<HTML>";
        strBody += "<head>";
        ////strBody += "<style type=\"text/css\">";
        //strBody += "h4 {display: block;margin-block-start: 1.33em;margin-block-end: 1.33em;margin-inline-start: 0px;margin-inline-end: 0px;font-weight: bold;font-size: 1.5rem;}";
        //strBody += "</style>";
        strBody += "</head>";
        strBody += "<Body> ";
        strBody += "<label> Informacion </label><br>";
        strBody += "<label><strong> Cliente: </strong>" + apellidoPaterno + " </label><br>";
        strBody += "----------------------------------------------------<br/>";
        foreach (System.Data.DataRow models in model)
        {
            strBody += "<label><strong> Trayecto Solicitado: </strong>" + models["fromDepartament"] + " - " + models["fromCity"] + " <strong>hacia</strong> " + models["toDepartament"] + " - " + models["toCity"] + " </label><br>";
            strBody += "<label><strong> Direccion Remitente: </strong>" + models["directionFrom"] + "</label><br>";
            strBody += "<label><strong> Direccion Destinatario: </strong>" + models["directionTo"] + "</label><br>";
            strBody += "<label><strong> Transportar: </strong>" + models["typeContainer"] + ", " + models["typeMerchandise"] + " en " + models["typeCargoString"] + " </label><br>";
            strBody += "<label><strong> Peso: </strong>" + models["weightContainer"] + " <strong>" + models["typeMeasuredString"] + "</strong></label><br>";
            if (Convert.ToInt32(models["typeCargo"]) == 2 || Convert.ToInt32(models["typeCargo"]) == 3 || Convert.ToInt32(models["typeCargo"]) == 4)
            {
                strBody += "<label><strong>Medidas: </strong> <strong>Largo: </strong>"+ models["longTied"] +", <strong>Ancho: </strong> "+ models["widthPlates"]+", <strong>Alto: </strong>"+ models["highLoose"]+ " en <strong>" + models["typeDimensionString"] +"</strong></label><br>";
                strBody += "<label><strong>Número: </strong>" + models["numberUnitsTons"]+"</label><br>";
            }
            //if(Convert.ToInt32(models["typeCargo"]) >= 3)
            //{
            //    strBody += "<label><strong>Presentación: </strong> <strong>Atado: </strong>" + models["longTied"] + ", <strong>Planchas: </strong>" + models["widthPlates"] + ", <strong>Suelta: </strong>" + models["highLoose"] + "</label><br>";
            //}
            strBody += "<label><strong> Valor por Contenedor:</strong> " + String.Format("{0:C0}", Convert.ToInt32(models["valueMerchandise"])) + " </label><br>";
            strBody += "<label><strong> Fecha de Viaje:</strong> " + models["departure"] + "</label><br>";
            strBody += "<label><strong>Fecha Estimada de Arribo</strong>: " + models["arrival"] + " </label><br>";
            strBody += "<label><strong> Observacion:</strong> " + models["observation"] + " </label><br>";
            strBody += "----------------------------------------------------<br/>";

        }
        //*/
        strBody += "    <label> Presiona el boton para ir a nuestros servicios</label></br> ";
        strBody += "<a href='"+ urlpath + "'><button class=\"curpointer\" style=\"cursor:pointer;background:#42a098;border-radius:5px;padding:15px 23px;color:#ffffff;" +
            "           display:inline-block;font:normal bold 30px/1 \"Calibri\", sans-serif;text-align:center;text-shadow:1px 1px #000000;cursor:pointer;\"> BidCargo </button></a> ";
        strBody += "<br><br>Cordialmente Servicio al cliente BidCargo";
        strBody += "<br><br><img src=\"http://www.bidcargo.com.co/Content/images/logoLetras.png\" width= \"249\" height=\"69\" alt=\"logo\">";
        strBody += "</Body>";
        strBody += "</HTML>";
        //strBody = strBody.Replace("{1}", celular);
        return strBody;
    }
    public string sendOfferMailTypeCompany(System.Data.DataRowCollection model, string apellidoPaterno, int pidTypeCompany, string urlpath)
    {
        string strBody = "<HTML>";
        strBody += "<head>";
        ////strBody += "<style type=\"text/css\">";
        //strBody += "h4 {display: block;margin-block-start: 1.33em;margin-block-end: 1.33em;margin-inline-start: 0px;margin-inline-end: 0px;font-weight: bold;font-size: 1.5rem;}";
        //strBody += "</style>";
        strBody += "</head>";
        strBody += "<Body> ";
        strBody += "<label> Informacion </label><br>";
        strBody += "<label><strong> Cliente: </strong>" + apellidoPaterno + " </label><br>";
        strBody += "----------------------------------------------------<br/>";
        foreach (dynamic models in model)
        {
            strBody += "<label><strong> Trayecto Solicitado: </strong>" + models["fromDepartament"] + " - " + models["fromCity"] + " <strong>hacia</strong> " + models["toDepartament"] + " - " + models["toCity"] + " </label><br>";
            strBody += "<label><strong> Direccion Remitente: </strong>" + models["directionFrom"] + "</label><br>";
            strBody += "<label><strong> Direccion Destinatario: </strong>" + models["directionTo"] + "</label><br>";
            strBody += "<label><strong> Transportar: </strong>" + models["typeContainer"] + ", " + models["typeMerchandise"] + " en " + models["typeCargoString"] + " </label><br>";
            strBody += "<label><strong> Peso: </strong>" + models["weightContainer"] + " <strong>" + models["typeMeasuredString"] + "</strong></label><br>";
            if (Convert.ToInt32(models["typeCargo"]) == 2 || Convert.ToInt32(models["typeCargo"]) == 3 || Convert.ToInt32(models["typeCargo"]) == 4)
            {
                strBody += "<label><strong>Medidas: </strong> <strong>Largo: </strong>" + models["longTied"] + ", <strong>Ancho: </strong> " + models["widthPlates"] + ", <strong>Alto: </strong>" + models["highLoose"] + " en <strong>" + models["typeDimensionString"] + "</strong></label><br>";
                strBody += "<label><strong>Número Unidades: </strong>" + models["numberUnitsTons"] + "</label><br>";
            }
            //if (Convert.ToInt32(models["typeCargo"]) >= 3)
            //{
            //    strBody += "<label><strong>Presentación: </strong> <strong>Atado: </strong>" + models["longTied"] + ", <strong>Planchas: </strong>" + models["widthPlates"] + ", <strong>Suelta: </strong>" + models["highLoose"] + " en <strong>" + models["typeDimensionString"] + "</strong></label><br>";
            //}
            strBody += "<label><strong> Valor Declarado Mercancia:</strong> " + String.Format("{0:C0}", Convert.ToInt32(models["valueMerchandise"])) + " </label><br>";
            if(pidTypeCompany == 2)
                strBody += "<label><strong> Valor de la Oferta:</strong> " + String.Format("{0:C0}", models["valorOferta"]) + "</label><br>";
            strBody += "<label><strong> Fecha de Viaje:</strong> " + models["departure"] + "</label><br>";
            strBody += "<label><strong>Fecha Estimada de Arribo</strong>: " + models["arrival"] + " </label><br>";
            strBody += "<label><strong> Observacion:</strong> " + models["observation"] + " </label><br>";
            strBody += "----------------------------------------------------<br/>";

        }
        dynamic roww = model[0];
        string variable =   RandomString(5) + "k"+roww["idClient"].ToString()+"k"+ 
                            RandomString(5)+"k"+roww["codeOffer"].ToString()+"k"+ 
                            RandomString(5) + "k" + pidTypeCompany.ToString() + "k" + 
                            RandomString(5);
        //*/
        strBody += "<label> Presiona el boton para ir a la pagina si quieres ofertar</label><br><br> ";
        strBody += "<a href='"+ urlpath+"/Home/OffersToken/" + variable + "'><button class=\"curpointer\" style=\"cursor:pointer;background:#42a098;border-radius:5px;padding:15px 23px;color:#ffffff;" +
            "           display:inline-block;font:normal bold 30px/1 \"Calibri\", sans-serif;text-align:center;text-shadow:1px 1px #000000;cursor:pointer;\">Aceptar</button></a> ";
        strBody += "<br><br>Cordialmente Servicio al cliente BidCargo";
        strBody += "<br><br><img src=\"http://www.bidcargo.com.co/Content/images/logoLetras.png \" width= \"249\" height=\"69\" alt=\"logo\">";
        strBody += "</Body>";
        strBody += "</HTML>";
        //strBody = strBody.Replace("{1}", celular);
        return strBody;
    }
}
